# Achievements of Students of IIITD - DBMS Project


> Always git pull before starting

## Configuration:
    $ git clone <url>
    $ cd dbms
    $ nano .env
        - PASSWORD = <password_to_postgres_user>
    $ python app.py

## Github commands
    - git add -A
    - git commit -m "<user> <description>"
    - git push -u origin master 
    if want to make a branch
    - git checkout -b <branch_name>
    - git add -A
    - git commit -m "<message>"
    - git push -u origin <branch_name>

# Vishrut
    - dropdowns for rollno etc
    - show in templates all results
    - shows gpa wise count of students

# Mohan and Bharti
    - css and formatting

# Sudeep
    - Admin tables in flask
    - Students queries integrate in flask
    - dropdowns